#!/bin/sh
#
#
# iOS自动编译静态库脚本，编译模拟器+真机版，并自动合并成一个.a
# 1. 首先在xcode配置完要编译的架构和最低支持iOS SDK版本；
# 2. 在下方TODO处修改你要生成的库的名称
# dev.keke@gmail.com  at.20190318
# 3. 将此脚本和.xcxx xcode工程文件放在同一目录执行即可；
# 4. 在桌面将会生成你需要的库
#


#要build的target名
#TODO: 如下变量修改为你要编译生成的库的名称
tgName="ECFaceSDK"

osa="lib"$tgName"_iphoneos.a"
sima="lib"$tgName"_iphonesimulator.a"
suma="lib"$tgName".a"


#如果存在删除当前已经编译的库
if [ -f $osa ];then
rm -rf $osa
fi

if [ -f $sima ];then
rm -rf $sima
fi

if [ -f $suma ];then
rm -rf $suma
fi

#build os
xcodebuild clean
xcodebuild -target $tgName -configuration Release -sdk iphoneos
mv build/Release-iphoneos/"lib"$tgName".a" ./$osa

#build sim
xcodebuild clean
xcodebuild -target $tgName -configuration Release -sdk iphonesimulator
mv build/Release-iphonesimulator/"lib"$tgName".a" ./$sima

xcodebuild clean

#sim+os
lipo -create ./$osa ./$sima -output ./$suma

#创建桌面的文件夹ECFaceSDK
filePath="~/Desktop/ECFaceSDK"
#判断ECFaceSDK文件夹是否存在
if [ ! -d "$filePath" ];then
mkdir $filePath
echo "创建文件夹成功"
else
echo "文件夹已经存在"
fi


#移动到用户的桌面
mv $suma ~/Desktop/


#如果不需要单独的模拟器文件和真文件可以删除
rm -rf $osa
rm -rf $sima


echo "------------------------------------"
echo ""
echo "building success."
echo ""
lipo -info ~/Desktop/$suma
echo ""
echo "------------------------------------"




